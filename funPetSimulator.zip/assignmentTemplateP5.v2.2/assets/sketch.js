let Asset1;
let Asset2;
let Asset3;
let Asset4;
let Asset5;
let Asset6;
let Asset7;
let funToy;
let petfood;
let toilet;
let toybox;
let bGround;
let secretBGround

function preload(){
 Asset1=loadImage("Assets/Asset1.png")
 Asset2=loadImage("Assets/Asset2.png")
 Asset3=loadImage("Assets/Asset3.png")
 Asset4=loadImage("Assets/Asset4.png")
 Asset5=loadImage("Assets/Asset5.png")
 Asset6=loadImage("Assets/Asset6.png")
 Asset7=loadImage("Assets/Asset7.png")
 funToy=loadImage("Assets/funToy.png")
 petfood=loadImage("Assets/petfood.png")
 toilet=loadImage("Assets/toilet.png")
 toybox=loadImage("Assets/toybox.png")
 bGround=loadImage("Assets/background.jpg")
 secretBGround=loadImage("Assets/secretBGround.jpg")
}

let funPet = [];
let gui;
let s;
let b1;
let b2;
let b3;
let secretButton;
let size = 200;
let growAmount = 10;
let grow;
let shrinkAmount = -10;
let shrink;
let shownImage;
//All images drawn by me

function setup() {
createCanvas(700, 700);
background(200);
  
  
gui = createGui();
gui.loadStyle("Blue");  
b1 = createButton("",70,545,50,60);
b2 = createButton("",260,420,120,160);
b3 = createButton("",520,420,50,220);
secretButton = createToggle("",640,320,50,30);
funPet = [Asset1, Asset2, Asset3, Asset4, Asset5, Asset6, Asset7]
s = createSlider("Slider",50,100,600,95,600);
}

function draw() {
background(bGround);
noStroke();
drawGui();
image(bGround,0,0,width,height)
  
if(secretButton.val) {
  image(secretBGround,0,0,width,height)
}
  
  fill(255,255,255);
  rect(35, 420,120,50);
  fill(0,0,0);
  text("Pick a Fun Pet™!",55,440)
  text("V V V V V V V V",50,455)
  text("V V V V V V V V",50,465)
  
  fill(255,255,255);
  rect(35, 270,130,50);
  fill(0,0,0);
  text("Chase Mr. Menthol™!",43, 285)
  text("^ ^ ^ ^ ^ ^ ^ ^",63, 300)
  text("^ ^ ^ ^ ^ ^ ^ ^",63, 310)
  
  fill(255,255,255);
  rect(255,320,120,50);
  fill(0,0,0);
  text("Feed Your Pet™!",275,340)
  text("V V V V V V V V",270,355)
  text("V V V V V V V V",270,365)
  
  fill(255,255,255);
  rect(480,340,150,50);
  fill(0,0,0);
  text("Watch Your Pet™ Crap!",493,360)
  text("V V V V V V V V",505,375)
  text("V V V V V V V V",505,385)
  
  fill(250,90,10);
  triangle(30,510,95,480,160,510);
  
  fill(160,160,160);
  rect(45, 510,100,100);
  
  fill(20,10,10);
  rect(60, 540,70,70);
  
  image(petfood,230,390,180,210)
  image(toilet,470,400,150,250)
  image(toybox,0,30,680,200)
  
if (s.isChanged) {
}
  image(funToy,s.val + 50,60,200,200)
  
if(b1.isPressed) {
  let i = Math.floor(random(0,funPet.length))
  shownImage = funPet[i]
  grow=false
}
  
if(shownImage != null){
  let introducedPet = image(shownImage,mouseX-100,mouseY-100,size,size)
  
  if(b1.isPressed) {
  let i = Math.floor(random(0,funPet.length))
  shownImage = funPet[i]
  grow=false
}
  
  if(b2.isPressed) {
  grow = true
    if (size > 400) {
    grow = false
  }
  if (size < 0.1) {
    grow = true
  }
  
  if (grow == true) {
    size += growAmount
  } else {
    size -= growAmount
  }
  }
  
  if(b3.isPressed) {
  shrink = true
    if (size < 400) {
    shrink = false
  }
  if (size > 0.1) {
    shrink = true
  }
  
  if (shrink == true) {
    size += shrinkAmount
  } else {
    size -= shrinkAmount
  }
  }
}
}