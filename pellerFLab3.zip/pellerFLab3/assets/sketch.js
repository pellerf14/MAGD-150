function setup() {
 createCanvas(500, 500);
  background(200);
}

function draw() {
let randomA = random(256);
let randomB = random(256);
let randomC = random(256);
let randomD = random(10000);
let d = sqrt(randomD);
let m = abs(-56,7); 
let pmx = pmouseX - 0;
let pmy = pmouseY - 0;
let mx = mouseX + 0;
let my = mouseY + 0;
  strokeWeight(d);
  line(pmx, pmy, mx, my);
  frameRate(m);

stroke(randomA,randomB,randomC,50)
 
  
}