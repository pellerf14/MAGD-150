
let needleX = []; 
function setup() {
createCanvas(400, 400);
for (let i = 0; i < 1000; i++) {

needleX[i] = random(-8000, 100);
}
}
function draw() {
background(255,130,255);
console.log();
for (let i = 0; i < needleX.length; i++) {
 if(i>width ){

 }
needleX[i] +=4;

let y = i * 0.4;


  fill(0, 255, 0);
  stroke(0,100,0)
  
  bezier(needleX[i],y,200,200,230,230,needleX[i],y)
}
}
  